<?php

class WC_Gateway_eCommerceConnect extends WC_Payment_Gateway {


	public $version;
	protected $data_to_send = array();
	protected $merchant_id;
	protected $terminal_id;
	protected $pem_file;
	protected $url;
	protected $lang;
	protected $response_url;
	protected $available_currencies;
	
	public function __construct() {
		$this->version      = WC_GATEWAY_ECOMMERCECONNECT_VERSION;
		$this->id           = 'ecommerceconnect';
		$this->method_title = __( 'eCommerceConnect', 'woocommerce-gateway-ecommerceconnect');
		$this->method_description  = sprintf( __( 'Accept card payments on your website via %1$seCommerceConnect%2$s payment gateway', 'woocommerce-gateway-ecommerceconnect' ), '<a href="https://ecconnect.upc.ua" target="_blank">', '</a>' );
		$this->icon                = WP_PLUGIN_URL . '/' . plugin_basename( dirname( __DIR__ ) ) . '/assets/images/icon.svg';
		$this->available_currencies = (array) apply_filters( 'woocommerce_gateway_ecommerceconnect_available_currencies', array( 'UAH') );

		$this->supports = array('products');

		$this->init_form_fields();
		$this->init_settings();

		$this->merchant_id      = $this->get_option( 'merchant_id' );
		$this->terminal_id      = $this->get_option( 'terminal_id' );
		$this->url              = 'https://secure.upc.ua/go/pay';
		$this->title            = $this->get_option( 'title' );
		$this->response_url     = add_query_arg( 'wc-api', strtolower(get_class($this)), home_url( '/' ) );
		$this->description      = $this->get_option( 'description' );
		$this->enabled          = 'yes' === $this->get_option( 'enabled' ) ? 'yes' : 'no';
		$this->lang             = $this->get_option( 'lang' );
		$this->skip_form        = 'yes' === $this->get_option( 'enabled' ) ? 'yes' : 'no';


		if ( 'yes' === $this->get_option( 'testmode' ) ) {
			$this->url          = 'https://ecg.test.upc.ua/go/pay';
			$this->add_testmode_admin_settings_notice();
		}

		add_action( 'woocommerce_api_' . strtolower(get_class($this)),  array( $this, 'callbackAction'));
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		add_action( 'woocommerce_receipt_ecommerceconnect', array( $this, 'receipt_page' ) );
		add_action( 'admin_notices', array( $this, 'admin_notices' ) );
		add_action( 'admin_notices', array( $this, 'admin_notices' ) );

		add_filter( 'woocommerce_currency', array( $this, 'filter_currency' ) );
		add_filter( 'nocache_headers', array( $this, 'no_store_cache_headers' ) );
	}

	public function no_store_cache_headers( $headers ) {
		if ( ! is_wc_endpoint_url( 'order-pay' ) ) {
			return $headers;
		}

		$headers['Cache-Control'] = 'no-cache, must-revalidate, max-age=0, no-store, private';
		return $headers;
	}

	public function init_form_fields() {
		$this->form_fields = array(
			'enabled'          => array(
				'title'       => __( 'Enable/Disable', 'woocommerce-gateway-ecommerceconnect' ),
				'label'       => __( 'Enable eCommerceConnect', 'woocommerce-gateway-ecommerceconnect' ),
				'type'        => 'checkbox',
				'description' => __( 'This controls whether or not this gateway is enabled within WooCommerce.', 'woocommerce-gateway-ecommerceconnect' ),
				'default'     => 'no',
				'desc_tip'    => true,
			),
			'title'            => array(
				'title'       => __( 'Title', 'woocommerce-gateway-ecommerceconnect' ),
				'type'        => 'text',
				'description' => __( 'This controls the title which the user sees during checkout.', 'woocommerce-gateway-ecommerceconnect' ),
				'default'     => __( 'eCommerceConnect', 'woocommerce-gateway-ecommerceconnect' ),
				'desc_tip'    => true,
			),
			'description'      => array(
				'title'       => __( 'Description', 'woocommerce-gateway-ecommerceconnect' ),
				'type'        => 'text',
				'description' => __( 'This controls the description which the user sees during checkout', 'woocommerce-gateway-ecommerceconnect' ),
				'default'     => 'Pay with eCommerceConnect (Debit/Credit Cards)',
				'desc_tip'    => true,
			),
			'testmode'         => array(
				'title'       => __( 'eCommerceConnect Sandbox', 'woocommerce-gateway-ecommerceconnect' ),
				'type'        => 'checkbox',
				'description' => __( 'Place the payment gateway in test mode', 'woocommerce-gateway-ecommerceconnect' ),
				'default'     => 'yes',
			),
			'merchant_id'      => array(
				'title'       => __( 'Merchant ID', 'woocommerce-gateway-ecommerceconnect' ),
				'type'        => 'text',
				'description' => __( 'This is the Merchant ID, received from eCommerceConnect', 'woocommerce-gateway-ecommerceconnect' ),
				'default'     => '',
			),
			'terminal_id'     => array(
				'title'       => __( 'Terminal ID', 'woocommerce-gateway-ecommerceconnect' ),
				'type'        => 'text',
				'description' => __( 'This is the Terminal ID, received from eCommerceConnect', 'woocommerce-gateway-ecommerceconnect' ),
				'default'     => '',
			),
			'lang'            => array(
				'title'       => __( 'eCommerceConnect interface language', 'woocommerce-gateway-ecommerceconnect' ),
				'type'        => 'select',
				'label'       => __( 'Set the payment gateway language', 'woocommerce-gateway-ecommerceconnect' ),
				'options'     => [
					'ua' => 'UA',
					'en' => 'EN',
				]
			),
			'skip_form'   => array(
				'title'   => __( 'Skip receipt page', 'woocommerce-gateway-ecommerceconnect' ),
				'type'    => 'checkbox',
				'label'   => __( 'Skip receipt page', 'woocommerce-gateway-ecommerceconnect' ),
				'default' => 'no',
			)
		);
	}

	public function get_required_settings_keys() {
		return array(
			'merchant_id',
			'terminal_id'
		);
	}

	public function needs_setup() {
		return ! $this->get_option( 'merchant_id' ) || ! $this->get_option( 'terminal_id' );
	}

	public function add_testmode_admin_settings_notice() {
		$this->form_fields['merchant_id']['description']  .= ' <strong>' . esc_html__( 'Sandbox Merchant ID currently in use', 'woocommerce-gateway-ecommerceconnect' ) . ' ( ' . esc_html( $this->merchant_id ) . ' )</strong>';
		$this->form_fields['terminal_id']['description'] .= ' <strong>' . esc_html__( 'Sandbox Terminal ID currently in use', 'woocommerce-gateway-ecommerceconnect' ) . ' ( ' . esc_html( $this->terminal_id ) . ' )</strong>';
	}

	public function check_requirements() {
		$errors = array(
			!in_array( get_woocommerce_currency(), $this->available_currencies, true ) ? 'wc-gateway-ecommerceconnect-error-invalid-currency' : null,
			empty( $this->get_option( 'merchant_id' ) ) ? 'wc-gateway-ecommerceconnect-error-missing-merchant-id' : null,
			empty( $this->get_option( 'terminal_id' ) ) ? 'wc-gateway-ecommerceconnect-error-missing-terminal-id' : null,
		);

		return array_filter( $errors );
	}

	public function is_available() {
		if ( 'yes' === $this->enabled ) {
			$errors = $this->check_requirements();
			return 0 === count( $errors );
		}

		return parent::is_available();
	}
	
	public function get_error_message( $key ) {
		switch ( $key ) {
			case 'wc-gateway-ecommerceconnect-error-invalid-currency':
				return esc_html__( 'Your store uses a currency that ecommerceconnect doesn\'t support yet.', 'woocommerce-gateway-ecommerceconnect' );
			case 'wc-gateway-ecommerceconnect-error-missing-merchant-id':
				return esc_html__( 'You forgot to fill your merchant ID.', 'woocommerce-gateway-ecommerceconnect' );
			case 'wc-gateway-ecommerceconnect-error-missing-terminal-id':
				return esc_html__( 'You forgot to fill your terminal ID.', 'woocommerce-gateway-ecommerceconnect' );			
			default:
				return '';
			}
	}
	
	public function admin_notices() {

		$errors_to_show = $this->check_requirements();

		if ( ! count( $errors_to_show ) ) return;

		if ( 'no' === $this->enabled ) 	return; 

		if ( ! get_transient( 'wc-gateway-ecommerceconnect-admin-notice-transient' ) ) {
			set_transient( 'wc-gateway-ecommerceconnect-admin-notice-transient', 1, 1 );

			echo '<div class="notice notice-error is-dismissible"><p>'
				. esc_html__( 'To use eCommerceConnect as a payment provider, you need to fix the problems below:', 'woocommerce-gateway-ecommerceconnect' ) . '</p>'
				. '<ul style="list-style-type: disc; list-style-position: inside; padding-left: 2em;">'
				. wp_kses_post(
					array_reduce(
						$errors_to_show,
						function ( $errors_list, $error_item ) {
							$errors_list = $errors_list . PHP_EOL . ( '<li>' . $this->get_error_message( $error_item ) . '</li>' );
							return $errors_list;
						},
						''
					)
				)
				. '</ul></p></div>';
		}
	}

	public function callbackAction(){

		if (!$_POST){
			return;
		}

        $order = wc_get_order($_POST['OrderID']);

        if ($_POST['TranCode'] === '000'){
			try{
				$order->set_status("wc-completed");
				$order->save();
			} catch(Exception $e){
				echo 'Message: ' .$e->getMessage();	
			}
		}		
		else {
			try{
				$order->set_status("wc-failed");
				$order->save();
			} catch(Exception $e){
				echo 'Message: ' .$e->getMessage();	
			}		
		}

			$frwrdUrl = $order->get_checkout_order_received_url();

            echo "MerchantID = " . $_POST['MerchantID'] . "\n";
            echo "TerminalID = " . $_POST['TerminalID'] . "\n";
            echo "OrderID = " . $_POST['OrderID'] . "\n";
            echo "Currency = " . $_POST['Currency'] . "\n";
            echo "TotalAmount = " . $_POST['TotalAmount'] . "\n";
            echo "XID = " . $_POST['XID'] . "\n";
            echo "PurchaseTime = " . $_POST['PurchaseTime'] . "\n";
            echo "ApprovalCode= " . $_POST['ApprovalCode'] . "\n";
            echo "SD= " . $_POST['SD'] . " \n";
            echo "TranCode= " . $_POST['TranCode'] . " \n";
            echo "Response.action= approve \n";
            echo "Response.reason= ok \n";
            echo "Response.forwardUrl= ". $frwrdUrl ." \n";
            die();
    }

	public function admin_options() {
		if ( in_array( get_woocommerce_currency(), $this->available_currencies, true ) ) {
	?>

		<h2><?php _e('eCommerceConnect', 'woocommerce-gateway-ecommerceconnect'); ?>
            <?php
            	if (function_exists('wc_back_link')) {
                	wc_back_link(__('Return to payments', 'woocommerce-gateway-ecommerceconnect'), admin_url('admin.php?page=wc-settings&tab=checkout'));
            	}
            ?>
        </h2>

        <h4>
            <strong><?php printf(__('Send this link to a <a href="%1$s" target="_blank" rel="noopener noreferrer">UPC specialist</a> to return to the store after payment <span style="color: red"><pre><code>%2$s</code></pre></span>', 'woocommerce-gateway-ecommerceconnect'), 'https://ecconnect.upc.ua', WC()->api_request_url(strtolower(get_class($this)))); ?></strong>
        </h4>
		<?php
			echo '<table class="form-table">';
			$this->generate_settings_html();
			echo '</table>';
		} else {
			?>
			<h3><?php esc_html_e( 'eCommerceConnect', 'woocommerce-gateway-ecommerceconnect' ); ?></h3>
			<div class="inline error">
				<p>
					<strong><?php esc_html_e( 'Gateway Disabled', 'woocommerce-gateway-ecommerceconnect' ); ?></strong>
					<?php
					echo wp_kses_post( sprintf( __( 'Choose UAH as your store currency in %1$sGeneral Settings%2$s to enable the eCommerceCcnnect Gateway.', 'woocommerce-gateway-ecommerceconnect' ), '<a href="' . esc_url( admin_url( 'admin.php?page=wc-settings&tab=general' ) ) . '">', '</a>' ) );
					?>
				</p>
			</div>
			<?php
		}
	}

	public function generate_ecommerceconnect_form( $order_id ) {

		$order = wc_get_order( $order_id );

		$currency = $order->get_currency()== 'UAH' ? '980' : null;		

		$orderID = ltrim( $order->get_order_number());
		$merchantID = $this->merchant_id;
        $terminalID = $this->terminal_id;
        $purchaseTime = date("ymdHis");
        $totalAmount = $order->get_total() * 100;
		$locale = $this->lang;
		$sd = wp_get_session_token();

        $data = "$merchantID;$terminalID;$purchaseTime;$orderID;$currency;$totalAmount;$sd;";

		if ( 'yes' === $this->get_option( 'testmode' )) {
			$pemFile = WP_PLUGIN_URL . '/' . plugin_basename( dirname( __DIR__ ) ) . '/cert/test/' . $merchantID . '.pem';
		} else {
			$pemFile = WP_PLUGIN_URL . '/' . plugin_basename( dirname( __DIR__ ) ) . '/cert/prod/' . $merchantID . '.pem';
		}

		if (file_exists($pemFile)) {
			$fp = fopen($pemFile, "r");
			$priv_key = fread($fp, 8192);
			fclose($fp);
			$pkeyid = openssl_get_privatekey($priv_key);
			openssl_sign($data, $signature, $pkeyid, OPENSSL_ALGO_SHA512);
			unset($pkeyid);
			$b64sign = base64_encode($signature);
		} else {
			echo 'Private key in not in folder or invalid';
			$b64sign = '';
		}
		
		$this->data_to_send = array(
			'Version'         => '1',
			'MerchantID'      => $merchantID,
			'TerminalID'      => $terminalID,
			'OrderID'         => $orderID,
			'TotalAmount'     => $totalAmount,
			'Currency'        => $currency,
			'PurchaseTime'    => $purchaseTime,
			'PurchaseDesc'    => get_bloginfo( 'name' ) . ' - ' . $order->get_order_number(),
			'SD'              => $sd,
			'locale'          => $locale,
			'Signature'       => $b64sign
		);
		
		$this->data_to_send = apply_filters( 'woocommerce_gateway_ecommerceconnect_payment_data_to_send', $this->data_to_send, $order_id );

		$ecommerceconnect_args_array = array();

		foreach ( $this->data_to_send as $key => $value ) {
			$ecommerceconnect_args_array[] = '<input type="hidden" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '" />';
		}

		echo '<form action="' . esc_url( $this->url ) . '" method="post" id="ecommerceconnect_payment_form">';
		echo implode( '', $ecommerceconnect_args_array );
		echo '<input type="submit" class="button-alt" id="submit_ecommerceconnect_payment_form" value="' . esc_attr__( 'Purchase', 'woocommerce-gateway-ecommerceconnect' ) . '"/>
				<a class="button btn alt btn-black"	href="' . esc_url( $order->get_cancel_order_url() ) . '">' .
					esc_html__( 'Back', 'woocommerce-gateway-ecommerceconnect' ) . '</a>';
		if('yes' === $this->get_option('skip_form')){
		echo '<script>
			jQuery(function(){
				jQuery("#submit_ecommerceconnect_payment_form" ).click();
		});
		</script>';
		}
		echo '</form>';
	}

	public function process_payment( $order_id ) {
		$order = wc_get_order( $order_id );
		return array(
			'result'   => 'success',
			'redirect' => $order->get_checkout_payment_url( true ),
		);
	}

	public function receipt_page( $order ) {
		echo '<p>' . esc_html__( 'Thank you for your order, please click the button below to pay with eCommerceConnect.', 'woocommerce-gateway-ecommerceconnect' ) . '</p>';
		$this->generate_ecommerceconnect_form( $order );
	}

	public function filter_currency( $currency ) {
		if ( ! class_exists( '\WCPay\MultiCurrency\MultiCurrency' ) ) {
			return $currency;
		}

		if ( is_admin() ) {
			return $currency;
		}

		$user_id = get_current_user_id();

		if ( isset( $_GET['currency'] ) ) {
			$currency_code = sanitize_text_field(
				wp_unslash( $_GET['currency'] ) 
			);
		} elseif ( 0 === $user_id && WC()->session ) {
			$currency_code = WC()->session->get( \WCPay\MultiCurrency\MultiCurrency::CURRENCY_SESSION_KEY );
		} elseif ( $user_id ) {
			$currency_code = get_user_meta( $user_id, \WCPay\MultiCurrency\MultiCurrency::CURRENCY_META_KEY, true );
		}

		if ( is_string( $currency_code ) && 'UAH' === $currency_code ) {
			return 'UAH';
		}

		return $currency;
	}
}